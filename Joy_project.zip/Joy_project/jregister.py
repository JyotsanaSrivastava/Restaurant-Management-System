from tkinter import *
import jlogin as log
from tkinter import messagebox
import pymysql as p

def register():
    def calllog():
        rwin.destroy()
        log.login()

    def store():
        str1 = unametxt.get()
        str2 = etxt.get()
        str3 = mobtxt.get()
        str4 = ptxt.get()
        str5 = cptxt.get()

        if str1 =="" or str2 =="" or str3 =="" or str4 =="" or str5 =="":
            messagebox.showerror("Empty Field", message="Fill up all Entries")
        elif str4 != str5:
            messagebox.showerror("Wrong Password", message="Password doesn't Match")
        elif str3.isnumeric() == FALSE or len(str3) != 10:
            messagebox.showerror("Wrong Credential", message="Mobile Number must have 10 digits")
        else:
            db = p.connect(user="root", host="localhost", password="pass@123", database="aptrondb")
            mycur = db.cursor()
            rquery = "insert into rest_data values(%s,%s,%s,%s,%s)"
            rval = (str1,str2,str3,str4,str5)
            mycur.execute(rquery,rval)
            db.commit()
            db.close()
            messagebox.showinfo("Registered", message="Registered Successfully")
            calllog()

    rwin = Tk()
    rwin.title("REGISTRATION PAGE")
    rwin.geometry("800x650")
    rwin.resizable(0, 0)
    rwin.config(bg="yellow")

    top = Label(rwin, font=('Times New Roman', 30), text="\nREGISTER HERE\n", bg="Steel blue", fg="Black")
    top.pack(fill=BOTH)
    uname = Label(rwin, font=('Times New Roman', 20), text="Enter your Username:", bg="yellow")
    unametxt = Entry(rwin, font=('Times New Roman', 20), bg="light green")
    email = Label(rwin, font=('Times New Roman', 20), text="Enter your Email:", bg="yellow")
    etxt = Entry(rwin, font=('Times New Roman', 20), bg="light green")
    mob = Label(rwin, font=('Times New Roman', 20), text="Enter your Mobile Number:", bg="yellow")
    mobtxt = Entry(rwin, font=('Times New Roman', 20), bg="light green")
    password = Label(rwin, font=('Times New Roman', 20), text="Enter your Password:", bg="yellow")
    ptxt = Entry(rwin, font=('Times New Roman', 20), bg="light green", show="*")
    cpassword = Label(rwin, font=('Times New Roman', 20), text="Confirm Password:", bg="yellow")
    cptxt = Entry(rwin, font=('Times New Roman', 20), bg="light green", show="*")

    uname.place(x=250,y=150)
    unametxt.place(x=250,y=180)
    email.place(x=250,y=230)
    etxt.place(x=250,y=260)
    mob.place(x=250,y=310)
    mobtxt.place(x=250,y=340)
    password.place(x=250,y=390)
    ptxt.place(x=250,y=420)
    cpassword.place(x=250,y=470)
    cptxt.place(x=250,y=500)

    regbtn = Button(rwin, text='REGISTER', font=('Times New Roman', 30), bg="light green", fg="black", command=store)
    regbtn.place(x=300, y=550)