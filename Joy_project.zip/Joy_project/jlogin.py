from tkinter import *
from tkinter import messagebox
import pymysql as p
import jrest as res

def login():
    def callres():
        lwin.destroy()
        res.rest()

    def check():
        str1 = unametxt.get()
        str2 = ptxt.get()

        if str1 =="" or str2 =="":
            messagebox.showerror("Empty Field", message="Fill up all Entries")
        else:
            db = p.connect(user="root", host="localhost", password="pass@123", database="aptrondb")
            mycur = db.cursor()
            lquery = "select Username,Password from rest_data where Username=%s and Password=%s"
            lval = (str1,str2)
            mycur.execute(lquery,lval)
            row = mycur.fetchall()
            c = 0
            for i in row:
                if str1 == i[0] and str2 == i[1]:
                    c += 1
            if c == 0:
                messagebox.showerror("Wrong Input", message="Either Email or Password is wrong")
            else:
                callres()
            db.commit()
            db.close()

    lwin = Tk()
    lwin.title("LOGIN PAGE")
    lwin.geometry("800x650")
    lwin.resizable(0, 0)
    lwin.config(bg="yellow")

    top = Label(lwin, font=('Times New Roman', 30), text="\nLOGIN HERE\n", bg="Steel blue", fg="Black")
    top.pack(fill=BOTH)
    uname = Label(lwin, font=('Times New Roman', 20), text="Enter your Username:", bg="yellow")
    unametxt = Entry(lwin, font=('Times New Roman', 20), bg="light green")
    password = Label(lwin, font=('Times New Roman', 20), text="Enter your Password:", bg="yellow")
    ptxt = Entry(lwin, font=('Times New Roman', 20), bg="light green", show="*")

    uname.place(x=250,y=250)
    unametxt.place(x=250,y=300)
    password.place(x=250,y=350)
    ptxt.place(x=250,y=400)
    logbtn = Button(lwin, text='LOGIN', font=('Times New Roman', 30), bg="light green", fg="black", command=check)
    logbtn.place(x=300, y=500)