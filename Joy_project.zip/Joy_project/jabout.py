from tkinter import *
import  jregister as reg

def about():
    def callregister():
        awin.destroy()
        reg.register()

    awin = Tk()
    awin.title("ABOUT_US PAGE")
    awin.geometry("800x650")
    awin.resizable(0, 0)
    awin.config(bg="yellow")

    top = Label(awin, font=('Times New Roman', 30), text="\nRESTAURANT MANAGEMENT SYSTEM\n", bg="Steel blue", fg="Black")
    top.pack(fill=BOTH)
    abt1 = Label(awin, font=('Times New Roman', 40), text="Serving You", bg="yellow")
    abt2 = Label(awin, font=('Times New Roman', 40), text="Since 2005", bg="yellow")

    abt1.place(x=250, y=250)
    abt2.place(x=250, y=350)

    regbtn = Button(awin, text='REGISTER HERE', font=('Times New Roman', 30), bg="light green", fg="black", command=callregister)
    regbtn.place(x=250, y=550)