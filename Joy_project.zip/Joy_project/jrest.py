from tkinter import *
import random
import datetime

amt = 0

def rest():
    def return_amt():
        root1 = Tk()
        root1.geometry("400x500+0+200")
        root1.title("AMOUNT")
        root1.config(bg="yellow")
        Top1 = Frame(root1)
        Top1.pack(side=TOP, fill=BOTH)

        lbltop = Label(Top1, font=('Times New Roman', 20, 'bold'), text="RETURN AMOUNT", bg="Steel blue",
                        fg="Black", bd=10, anchor='center')
        lbltop.pack(fill=BOTH)

        def calculate():
            global amt

            if n2000.get() == '':
                twoth = 0
            else:
                twoth = int(n2000.get())
            if n500.get() == '':
                fiveh = 0
            else:
                fiveh = int(n500.get())
            if n200.get() == '':
                twoh = 0
            else:
                twoh = int(n200.get())
            if n100.get() == '':
                hundred = 0
            else:
                hundred = int(n100.get())
            if n50.get() == '':
                fifty = 0
            else:
                fifty = int(n50.get())
            if n20.get() == '':
                twenty = 0
            else:
                twenty = int(n20.get())
            if n10.get() == '':
                ten = 0
            else:
                ten = int(n10.get())

            z = Total.get().find(')')
            total = Total.get()[8:z-1]

            damt = float((twoh)*200 + (twoth)*2000 + (twenty)*20 + (fifty)*50 + (fiveh)*500 + (hundred)*100 + (ten)*10)
            amt = damt - float(total)

            lblinfo = Label(root1, font=('Times New Roman', 16, 'bold'), text='Deposited Amount :'+ str(damt) + '\nTotal Amount :' + total + '\nReturn Amount :'+'%.2f' %amt, anchor="center", fg="black",
                            bg="yellow")
            lblinfo.place(x=70, y=340)


        lblinfo = Label(root1, font=('arial', 16, 'bold'), text=" Rupees ", anchor="center", fg="black", bg="light green")
        lblinfo.place(x=50,y=70)
        lblinfo = Label(root1, font=('arial', 16, 'bold'), text=" Number ", fg="black", anchor=W, bg="light green")
        lblinfo.place(x=230,y=70)
        lblinfo = Label(root1, font=('aria', 15, 'bold'), text="    2000", anchor=W, bg="yellow")
        lblinfo.place(x=50,y=110)
        n2000 = Entry(root1, font=('aria', 15, 'bold'), width=5, bg="light green")
        n2000.place(x=250,y=110)
        lblinfo = Label(root1, font=('aria', 15, 'bold'), text="    500", anchor=W, bg="yellow")
        lblinfo.place(x=50,y=140)
        n500 = Entry(root1, font=('aria', 15, 'bold'), width=5, bg="light green")
        n500.place(x=250,y=140)
        lblinfo = Label(root1, font=('aria', 15, 'bold'), text="    200", anchor=W,
                        bg="yellow")
        lblinfo.place(x=50,y=170)
        n200 = Entry(root1, font=('aria', 15, 'bold'), width=5, bg="light green")
        n200.place(x=250,y=170)
        lblinfo = Label(root1, font=('aria', 15, 'bold'), text="    100", anchor=W,
                        bg="yellow")
        lblinfo.place(x=50,y=200)
        n100 = Entry(root1, font=('aria', 15, 'bold'), width=5, bg="light green")
        n100.place(x=250,y=200)
        lblinfo = Label(root1, font=('aria', 15, 'bold'), text="    50", anchor=W,
                        bg="yellow")
        lblinfo.place(x=50,y=230)
        n50 = Entry(root1, font=('aria', 15, 'bold'), width=5, bg="light green")
        n50.place(x=250,y=230)
        lblinfo = Label(root1, font=('aria', 15, 'bold'), text="    20", anchor=W,
                        bg="yellow")
        lblinfo.place(x=50,y=260)
        n20 = Entry(root1, font=('aria', 15, 'bold'), width=5, bg="light green")
        n20.place(x=250,y=260)
        lblinfo = Label(root1, font=('aria', 15, 'bold'), text="    10", anchor=W,
                        bg="yellow")
        lblinfo.place(x=50,y=290)
        n10 = Entry(root1, font=('aria', 15, 'bold'), width=5, bg="light green")
        n10.place(x=250,y=290)

        btnamt = Button(root1, fg="black", font=('arial', 20, 'bold'), text="Calculate",
                          bg="light green", command=calculate)
        btnamt.place(x=120,y=420)

    root = Tk()
    root.geometry("1600x2000")
    root.title("Restaurant Management System")
    root.config(bg="yellow")
    Tops = Frame(root, width=1600, relief=SUNKEN)
    Tops.pack(side=TOP, fill=BOTH)

    f1 = Frame(root, width=1600, height=1000, relief=SUNKEN, bg="yellow")
    f1.pack(side=LEFT)

# =================================================================================
#                  TIME
# ================================================================================
    localdate = datetime.date.today().strftime("%d %B %Y")

    lblInfo = Label(Tops, font=('Times New Roman', 50, 'bold'), text="RESTAURANT MANAGEMENT SYSTEM", bg="Steel blue", fg="Black", bd=10, anchor='center')
    lblInfo.pack(fill=BOTH)

    lblInfo = Label(Tops, font=('Times New Roman', 20, 'bold'), text=localdate, bg="Steel Blue", fg="white", bd=10, anchor='center')
    lblInfo.pack(fill=BOTH)

    def Ref():
        global ser_Charge
        global PayTax
        global TotalCost

        x = random.randint(10908, 500876)
        randomRef = str(x)
        rand.set(randomRef)

        if (Fries.get() == ""):
            CoFries = 0
        else:
            CoFries = float(Fries.get())

        if (Noodles.get() == ""):
            CoNoodles = 0
        else:
            CoNoodles = float(Noodles.get())

        if (Soup.get() == ""):
            CoSoup = 0
        else:
            CoSoup = float(Soup.get())

        if (Burger.get() == ""):
            CoBurger = 0
        else:
            CoBurger = float(Burger.get())

        if (Sandwich.get() == ""):
            CoSandwich = 0
        else:
            CoSandwich = float(Sandwich.get())

        if (Drinks.get() == ""):
            CoD = 0
        else:
            CoD = float(Drinks.get())

        CostofFries = CoFries * 120
        CostofDrinks = CoD * 65
        CostofNoodles = CoNoodles * 100
        CostofSoup = CoSoup * 150
        CostBurger = CoBurger * 160
        CostSandwich = CoSandwich * 80

        CostofMeal = "Rs", str(
            '%.2f' % (CostofFries + CostofDrinks + CostofNoodles + CostofSoup + CostBurger + CostSandwich))

        PayTax = ((CostofFries + CostofDrinks + CostofNoodles + CostofSoup + CostBurger + CostSandwich) * 0.2)

        TotalCost = (CostofFries + CostofDrinks + CostofNoodles + CostofSoup + CostBurger + CostSandwich)

        Ser_Charge = ((CostofFries + CostofDrinks + CostofNoodles + CostofSoup + CostBurger + CostSandwich) / 99)

        Service = "Rs", str('%.2f' % Ser_Charge)

        OverAllCost = "Rs", str('%.2f' % (PayTax + TotalCost + Ser_Charge))

        PaidTax = "Rs", str('%.2f' % PayTax)

        Service_Charge.set(Service)
        Cost.set(CostofMeal)
        Tax.set(PaidTax)
        SubTotal.set(CostofMeal)
        Total.set(OverAllCost)
        return_amt()


    def qExit():
        root.destroy()


    def Reset():
        rand.set("")
        Fries.set("")
        Noodles.set("")
        Soup.set("")
        SubTotal.set("")
        Total.set("")
        Service_Charge.set("")
        Drinks.set("")
        Tax.set("")
        Cost.set("")
        Burger.set("")
        Sandwich.set("")


# ====================================Restaraunt Info 1===========================================================
    rand = StringVar()
    Fries = StringVar()
    Noodles = StringVar()
    Soup = StringVar()
    SubTotal = StringVar()
    Total = StringVar()
    Service_Charge = StringVar()
    Drinks = StringVar()
    Tax = StringVar()
    Cost = StringVar()
    Burger = StringVar()
    Sandwich = StringVar()
    lb = Label(f1, text="______________", font=('', 16), fg="yellow", bg="yellow")
    lb.grid(row=0, column=1)
    lblReference = Label(f1, font=('arial', 16, 'bold'), text="Reference", bd=16, anchor="w", bg="yellow")
    lblReference.grid(row=0, column=2)
    txtReference = Entry(f1, font=('arial', 16, 'bold'), textvariable=rand, bd=10, insertwidth=4, bg="light green",
                     justify='right')
    txtReference.grid(row=0, column=3)

    lblFries = Label(f1, font=('arial', 16, 'bold'), text="Fries", bd=16, anchor="w", bg="yellow")
    lblFries.grid(row=1, column=2)
    txtFries = Entry(f1, font=('arial', 16, 'bold'), textvariable=Fries, bd=10, insertwidth=4, bg="light green",
                 justify='right')
    txtFries.grid(row=1, column=3)

    lblNoodles = Label(f1, font=('arial', 16, 'bold'), text="Noodles", bd=16, anchor="w", bg="yellow")
    lblNoodles.grid(row=2, column=2)
    txtNoodles = Entry(f1, font=('arial', 16, 'bold'), textvariable=Noodles, bd=10, insertwidth=4, bg="light green",
                   justify='right')
    txtNoodles.grid(row=2, column=3)

    lblSoup = Label(f1, font=('arial', 16, 'bold'), text="Soup", bd=16, anchor="w", bg="yellow")
    lblSoup.grid(row=3, column=2)
    txtSoup = Entry(f1, font=('arial', 16, 'bold'), textvariable=Soup, bd=10, insertwidth=4, bg="light green",
                justify='right')
    txtSoup.grid(row=3, column=3)

    lblBurger = Label(f1, font=('arial', 16, 'bold'), text="Burger", bd=16, anchor="w", bg="yellow")
    lblBurger.grid(row=4, column=2)
    txtBurger = Entry(f1, font=('arial', 16, 'bold'), textvariable=Burger, bd=10, insertwidth=4, bg="light green",
                  justify='right')
    txtBurger.grid(row=4, column=3)

    lblSandwich = Label(f1, font=('arial', 16, 'bold'), text="Sandwich", bd=16, anchor="w", bg="yellow")
    lblSandwich.grid(row=5, column=2)
    txtSandwich = Entry(f1, font=('arial', 16, 'bold'), textvariable=Sandwich, bd=10, insertwidth=4, bg="light green",
                    justify='right')
    txtSandwich.grid(row=5, column=3)

# ========================================================================================
#                                RESTAURANT INFO 2
# ========================================================================================

    lblDrinks = Label(f1, font=('arial', 16, 'bold'), text="Drinks", bd=16, anchor="w", bg="yellow")
    lblDrinks.grid(row=0, column=4)
    txtDrinks = Entry(f1, font=('arial', 16, 'bold'), textvariable=Drinks, bd=10, insertwidth=4, bg="light green",
                  justify='right')
    txtDrinks.grid(row=0, column=5)

    lblCost = Label(f1, font=('arial', 16, 'bold'), text="Cost of Meal", bd=16, anchor="w", bg="yellow")
    lblCost.grid(row=1, column=4)
    txtCost = Entry(f1, font=('arial', 16, 'bold'), textvariable=Cost, bd=10, insertwidth=4, bg="light green",
                justify='right')
    txtCost.grid(row=1, column=5)

    lblService = Label(f1, font=('arial', 16, 'bold'), text="Service Charge", bd=16, anchor="w", bg="yellow")
    lblService.grid(row=2, column=4)
    txtService = Entry(f1, font=('arial', 16, 'bold'), textvariable=Service_Charge, bd=10, insertwidth=4, bg="light green",
                   justify='right')
    txtService.grid(row=2, column=5)

    lblStateTax = Label(f1, font=('arial', 16, 'bold'), text="State Tax", bd=16, anchor="w", bg="yellow")
    lblStateTax.grid(row=3, column=4)
    txtStateTax = Entry(f1, font=('arial', 16, 'bold'), textvariable=Tax, bd=10, insertwidth=4, bg="light green",
                    justify='right')
    txtStateTax.grid(row=3, column=5)

    lblSubTotal = Label(f1, font=('arial', 16, 'bold'), text="Sub Total", bd=16, anchor="w", bg="yellow")
    lblSubTotal.grid(row=4, column=4)
    txtSubTotal = Entry(f1, font=('arial', 16, 'bold'), textvariable=SubTotal, bd=10, insertwidth=4, bg="light green",
                    justify='right')
    txtSubTotal.grid(row=4, column=5)

    lblTotalCost = Label(f1, font=('arial', 16, 'bold'), text="Total Cost", bd=16, anchor="w", bg="yellow")
    lblTotalCost.grid(row=5, column=4)
    txtTotalCost = Entry(f1, font=('arial', 16, 'bold'), textvariable=Total, bd=10, insertwidth=4, bg="light green",
                         justify='right')
    txtTotalCost.grid(row=5, column=5)

# ==========================================Buttons==========================================================================================
    btnTotal = Button(f1, fg="black", font=('Times New Roman', 30, 'bold'), width=10, text="TOTAL",
                  bg="light green", command=Ref).grid(row=7, column=4)

    btnReset = Button(f1, fg="black", font=('Times New Roman', 30, 'bold'), width=10, text="RESET",
                  bg="light green", command=Reset).grid(row=7, column=3)

    btnExit = Button(f1, fg="black", font=('Times New Roman', 30, 'bold'), width=10, text="EXIT",
                 bg="light green", command=qExit).grid(row=7, column=5)


    def price():
        roo = Tk()
        roo.geometry("330x360+25+200")
        roo.resizable(0,0)
        roo.title("Price List")
        roo.config(bg="light green")
        lblinfo = Label(roo, font=('aria', 16, 'bold'), text="    ITEM", fg="black", bd=5, bg="light green")
        lblinfo.grid(row=0, column=0)
        lb1 = Label(roo, text="________", font=('', 16), fg="light green", bg="light green")
        lb1.grid(row=0, column=1)
        lblinfo = Label(roo, font=('aria', 16, 'bold'), text="PRICE", fg="black", anchor=W, bg="light green")
        lblinfo.grid(row=0, column=3)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="    Fries\n", fg="steel blue", anchor=W, bg="light green")
        lblinfo.grid(row=1, column=0)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="120\n", fg="steel blue", anchor=W, bg="light green")
        lblinfo.grid(row=1, column=3)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="    Soup\n", fg="steel blue", anchor=W, bg="light green")
        lblinfo.grid(row=2, column=0)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="150\n", fg="steel blue", anchor=W, bg="light green")
        lblinfo.grid(row=2, column=3)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="    Burger\n", fg="steel blue", anchor=W, bg="light green")
        lblinfo.grid(row=3, column=0)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="160\n", fg="steel blue", anchor=W, bg="light green")
        lblinfo.grid(row=3, column=3)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="    Sandwich\n", fg="steel blue", anchor=W, bg="light green")
        lblinfo.grid(row=4, column=0)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="80\n", fg="steel blue", anchor=W, bg="light green")
        lblinfo.grid(row=4, column=3)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="    Noodles\n", fg="steel blue", anchor=W, bg="light green")
        lblinfo.grid(row=5, column=0)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="100\n", fg="steel blue", anchor=W, bg="light green")
        lblinfo.grid(row=5, column=3)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="    Drinks\n", fg="steel blue", anchor=W, bg="light green")
        lblinfo.grid(row=6, column=0)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="65\n", fg="steel blue", anchor=W, bg="light green")
        lblinfo.grid(row=6, column=3)

        roo.mainloop()


    btnprice = Button(f1, fg="black", font=('Times New Roman', 30, 'bold'), width=10, text="PRICE",
                  bg="light green", command=price)
    btnprice.grid(row=7, column=0)

    root.mainloop()
