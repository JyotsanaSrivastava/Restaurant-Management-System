from tkinter import *
import jabout as abt
import jlogin as log
import jregister as reg

def callabout():
    mainwin.destroy()
    abt.about()

def calllogin():
    mainwin.destroy()
    log.login()

def callregister():
    mainwin.destroy()
    reg.register()

if __name__ == "__main__":
    mainwin = Tk()
    mainwin.title("RESTAURANT MANAGEMENT SYSTEM")
    mainwin.geometry("800x650")
    mainwin.resizable(0, 0)
    mainwin.config(bg="yellow")

top = Label(mainwin, font=('Times New Roman', 30), text="\nRESTAURANT MANAGEMENT SYSTEM\n", bg="Steel blue", fg="Black")
top.pack(fill=BOTH)
logbtn = Button(mainwin, text='LOGIN', font=('Times New Roman', 30), bg="light green", fg="black", command=calllogin)
logbtn.place(x=300, y=250)
regbtn = Button(mainwin, text='REGISTER', font=('Times New Roman', 30), bg="light green", fg="black", command=callregister)
regbtn.place(x=270, y=350)
abbtn = Button(mainwin, text='ABOUT_US', font=('Times New Roman', 30), bg="light green", fg="black", command=callabout)
abbtn.place(x=260, y=450)

mainwin.mainloop()